﻿using BackendAssment.Models.LoginTable;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BackendAssment.Repositories.LoginRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Threading.Tasks;
using BackendAssment.Models.UserTable;

namespace BackendAssment.Controllers.LoginController
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IConfiguration configuration;
        private readonly Ilogin ilogin;
        public LoginController(IConfiguration configuration, Ilogin ilogin)
        {
            this.configuration = configuration;
            this.ilogin = ilogin;
        }

        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromForm] LoginModel user)
        {
            if (ModelState.IsValid)
            {
                var user1 =await ilogin.Login(user);
                if (user1.Email == null)
                {
                    return Unauthorized(
                        new
                        {
                            err=1,
                            msg = "Invalid Credentials"
                        });
                }
                
                var token = IssueToken(user1);

                return Ok(token);
            }
            return BadRequest("Invalid Request Body");
        }

        private string IssueToken(UserModel user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"] ?? ""));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
            new(ClaimTypes.NameIdentifier, user.Email ?? ""),
            new(ClaimTypes.Email, user.Email ?? ""),
            new(ClaimTypes.Role, user.Role ?? ""),
            new(ClaimTypes.StateOrProvince, user.status.ToString() ?? "")

            };

            var token = new JwtSecurityToken(
                issuer: configuration["Jwt:Issuer"],
                audience: configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.Now.AddHours(1),
                signingCredentials: credentials
                );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }


    }
}

