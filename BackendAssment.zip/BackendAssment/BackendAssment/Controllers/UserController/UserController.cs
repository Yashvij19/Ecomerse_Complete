﻿using BackendAssment.Models.UserTable;
using BackendAssment.Repositories.UserRepository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BackendAssment.Controllers.UserController
{
    [Route("api/[controller]/[Action]")]
    [ApiController]

    public class UserController : ControllerBase
    {

        private readonly IUser Iuser;

        public UserController(IUser user) {
        
            this.Iuser = user;

        }


        // GET: api/<UserController>
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> GetAllUser()
        {
            List<UserModel> lst = await Iuser.GetAllUser();
            return Ok(new{
                err = 1,
                msg = "User List",
                data = lst
            }


            );
        }


        // GET api/<UserController>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
           var data = await  Iuser.GetById(id);
            if (data.Email != null)
            {
                return Ok(new
                {
                    err = 1,
                    msg = "User Found",
                    data = data
                });
            }
            else
            {
                return NotFound(new
                {
                    err = 0,
                    msg = "User Not Found",
                });
            }
        }

        // POST api/<UserController>
        [HttpPost]
        public async Task<IActionResult> AddUser([FromBody] UserModel model)
        {
           
            
                var data =  await Iuser.AddUser(model);
            if (data != null) {
                return Ok(new
                {
                    err = 0,
                    msg = "User Added susseffuly",
                    data = data
                }
                );
            }
            else
            {
                return BadRequest(new
                {
                    err = 1,
                    msg = "User Already Exist",
                });
            }
               
          
        }

        // PUT api/<UserController>/5
        [HttpPut("{id:int}")]
        public async Task<IActionResult> UpdateUserById(int id, [FromBody] UserModel value)
        {
            var data= await Iuser.UpdateUserById(id, value);
            if (data.Email != "")
            {
                return Ok(new
                {
                    err = 1,
                    msg = "User Updated",
                    data = data
                });
            }
            else
            {
                return NotFound(new
                {
                    err = 0,
                    msg = "User Not Found",
                });
            }

        }

        [HttpPut("{email}")]
        public async Task<IActionResult> UpdateUserById(string email, [FromBody] UserModel value)
        {
            var data = await Iuser.UpdateUserByEmail(email, value);
            if (data.Email != "")
            {
                return Ok(new
                {
                    err = 1,
                    msg = "User Updated",
                    data = data
                });
            }
            else
            {
                return NotFound(new
                {
                    err = 0,
                    msg = "User Not Found",
                });
            }

        }

        [HttpGet("{id}")]
        [Authorize(Roles ="Admin")]

        public async Task<IActionResult> changeStatus(int id)
        {
            bool flag = await Iuser.statusChange(id);
            if (flag)
            {
                return Ok(
                    new
                    {
                        err = 0,
                        msg="status change success"
                    });

            }
            else
            {
                return BadRequest(
                    new
                    {
                        err = 1,
                        msg = "user not exist"
                    }
                    );
            }
        }


        // DELETE api/<UserController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var data = await Iuser.DeleteById(id);

            if (data.Email != "")
            {
                return Ok(new
                {
                    err = 1,
                    msg = "User Deleted",
                    data = data
                });
            }
            else
            {
                return NotFound(new
                {
                    err = 0,
                    msg = "User Not Found",
                });
            }
        }
    }
}
