﻿using System.Threading.Tasks;
using BackendAssment.Models.ProductTable;
using BackendAssment.Repositories.ProductRepository;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace BackendAssment.Controllers.ProductController
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class ProductController : ControllerBase
    {

        private readonly Iproduct ip;
        public ProductController(Iproduct ip)
        {
            this.ip = ip;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllProducts()
        {
            List <ProductUiModel> lst = await ip.GetAllProduct();
            return Ok(new
            {
                err = 0,
                data=lst,
                msg="Product list is fetched"

            });

        }
        [HttpGet]
        public async Task<IActionResult> GetAllProductsDb()
        {
            List<ProductDbModel> lst = await ip.GetAllProductDb();
            return Ok(new
            {
                err = 0,
                data = lst,
                msg = "Product list is fetched"

            });

        }

        // GET api/<ValuesController>/5
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var data= await ip.GetById(id);
            if (data.ProductName != null)
            {
                return Ok(
                    new
                    {
                        err = 0,
                        data = data,
                        msg = "Product Found"
                    });
            }
            else
            {
                return NotFound(new
                {
                    err = 1,
                    msg = "Product Not Found"
                });
            }
        }

        // POST api/<ValuesController>
        [HttpPost]
        public async Task<IActionResult> AddProduct([FromForm] ProductUiModel product)
        {
            if (ModelState.IsValid)
            {
                bool data =await ip.AddProduct(product);
                if (data)
                {
                    return Ok(new
                    {
                        err = 0,
                        msg = "Product Added",
                        data = product
                    });
                }
                else
                {
                    return NotFound(new
                    {
                        err = 1,
                        msg = "Product Already Exist"
                    });
                }
            }
            else
            {
                return BadRequest(new
                {
                    err = 1,
                    msg = "Invalid Data"
                });
            }

        }

        // PUT api/<ValuesController>/5
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromForm] ProductUiModel model)
        {
            var data = await ip.UpdateProduct(id, model);
            if (data !=null)
            {
                return Ok(new
                {
                    err = 0,
                    msg = "Product Updated",
                    data = data
                });
            }
            else
            {
                return NotFound(new
                {
                    err = 1,
                    msg = "Product is not exist"
                });
            }
        }
        // DELETE api/<ValuesController>/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
                var data = await ip.DeleteById(id);
                if (data!= null )
                {
                    return Ok(new
                    {
                        err = 0,
                        msg = "Product Deleted",
                        data = data
                    });
                }
                else
                {
                    return NotFound(new
                    {
                        err = 1,
                        msg = "Product Not Found"
                    });
                }
            }
    }
}
