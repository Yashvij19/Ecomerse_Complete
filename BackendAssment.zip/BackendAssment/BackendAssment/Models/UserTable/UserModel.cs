﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using BackendAssment.Models.OrderTable;
namespace BackendAssment.Models.UserTable
{
    public class UserModel
    {

        [Key]
        public int UserId { get; set; }

        [Required]
        public string? UserName { get; set; }
        [Required]
        [EmailAddress]
        public string? Email { get; set; }

        [Required]
        public string? Password { get; set; }


        [Required]
        public string? Phone { get; set; }

        [Required]
        public string? Address { get; set; }

        public string CreditCard { get; set; } = "0000" ;
       
        public int status { get; set; } = 1;    

        public string? Role { get; set; } = "User";

        [JsonIgnore]
        public virtual ICollection<OrderModel> OrderModels { get; set; } = new List<OrderModel>();


    }
}
