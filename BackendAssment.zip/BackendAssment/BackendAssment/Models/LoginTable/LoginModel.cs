﻿namespace BackendAssment.Models.LoginTable
{
    public class LoginModel
    {
     
        public string? Password { get; set; }
        public string? Email { get; set; }
       
    }
}
