﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BackendAssment.Models.UserTable;
using BackendAssment.Models.OrderInfoTable;

namespace BackendAssment.Models.OrderTable
{
    public class OrderModel
    {
        [Key]
        public int OrderId { get; set; }

        [Required]
        public int UserId { get; set; }

        [Required] 
        public DateTime OrderDate { get; set; }= DateTime.Now;

        [Required]
        public long TotalAmount { get; set; }


        [Required]
        public string? PaymentMethod { get; set; }= "Cash On Delivery";


        [ForeignKey("UserId")]
        public virtual UserModel? User { get; set; }


        public virtual ICollection<OrderItemModel>? OrderItems { get; set; } = new List<OrderItemModel>();

    }
}
