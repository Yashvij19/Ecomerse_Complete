﻿using System.ComponentModel.DataAnnotations;

namespace BackendAssment.Models.ProductTable
{
    public class ProductUiModel
    {

        

        [Required]
        public string? ProductName { get; set; }

        [Required]
        public string? Description { get; set; }

        [Required]
        public long Price { get; set; }

        [Required]
        public int QunatityInStock { get; set; }

        [Required]
        public IFormFile? Image { get; set; }
        
        [Required]
        public string? Feature { get; set; }

        [Required]
        public string? Category { get; set; }
    }
}
