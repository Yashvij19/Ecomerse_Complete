﻿using System.ComponentModel.DataAnnotations;
using BackendAssment.Models.OrderInfoTable;
namespace BackendAssment.Models.ProductTable

{
    public class ProductDbModel
    {
        [Key]
        public int  ProductId { get; set; }

        [Required]
        public string? ProductName { get; set; }

        [Required]
        public string? Description { get; set; }

        [Required]
       public long Price  { get; set; }


        [Required]
        public int QunatityInStock { get; set; }

        [Required]
        public string? ImgPath { get; set; }


        [Required]
        public string? Feature { get; set; }


        [Required]
        public string? Category { get; set; }

        //navigation property 

        public virtual ICollection<OrderItemModel> OrderItems { get; set; }
    }
}
