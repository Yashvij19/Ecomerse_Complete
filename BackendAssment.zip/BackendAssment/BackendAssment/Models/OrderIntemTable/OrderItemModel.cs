﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BackendAssment.Models.OrderTable;
using BackendAssment.Models.ProductTable;

namespace BackendAssment.Models.OrderInfoTable
{
    public class OrderItemModel
    {
        [Key]
        public int OrderItemId { get; set; }

        [Required]
        public int OrderId { get; set; }

        [Required]
        public int ProductId { get; set; }


        [Required]
        public int Quantity { get; set; }

        [Required]
        public long Price { get; set; }


        [ForeignKey("OrderId")]
        public virtual OrderModel? Order { get; set; }

        [ForeignKey("ProductId")]
        public virtual ProductDbModel? Product { get; set; }

    }
}
