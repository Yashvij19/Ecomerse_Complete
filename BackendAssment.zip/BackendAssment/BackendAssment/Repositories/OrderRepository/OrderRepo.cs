﻿using BackendAssment.DataAccessLayer;

using BackendAssment.Models.OrderTable;
using Microsoft.EntityFrameworkCore;
namespace BackendAssment.Repositories.OrderRepository
{
    public class OrderRepo : Iorder
    {
        private readonly DataBaseDbContext db;
        public OrderRepo(DataBaseDbContext dbContext)
        {
            db = dbContext;
        }
        public async Task<bool> AddOrder(OrderModel order)
        {
            db.Orders.Add(order);
            await db.SaveChangesAsync();
            return true;
        }

        public async Task<OrderModel> GetById(int id)
        {
            var data = await db.Orders.Where(x => x.OrderId == id).FirstOrDefaultAsync();
            if (data != null)
            {
                return data;
            }
            else
            {
                return new OrderModel();
            }

        }
        public async Task<List<OrderModel>> GetByUserId(int userId)
        {
            List<OrderModel> lst = await db.Orders.Where(x => x.UserId == userId).ToListAsync();
            if (lst != null)
            {
                return lst;
            }
            else
            {
                return new List<OrderModel>();
            }
        }
    }
}
    
    

