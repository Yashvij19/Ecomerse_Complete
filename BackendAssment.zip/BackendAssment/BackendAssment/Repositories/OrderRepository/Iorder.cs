﻿using BackendAssment.Models.OrderTable;

namespace BackendAssment.Repositories.OrderRepository
{
    public interface Iorder
    {

        Task<bool> AddOrder(OrderModel order);
        //Task<OrderModel> UpdateOrder(int id, OrderModel order);
      
        Task<OrderModel> GetById(int id);
        Task<List<OrderModel>> GetByUserId(int userId);


    }
}
