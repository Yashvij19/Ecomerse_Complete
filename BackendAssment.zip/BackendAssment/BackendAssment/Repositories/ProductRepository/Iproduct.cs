﻿using BackendAssment.Models.ProductTable;

namespace BackendAssment.Repositories.ProductRepository
{
    public interface Iproduct
    {
       Task<bool> AddProduct(ProductUiModel product);
        Task<ProductUiModel? > UpdateProduct(int id, ProductUiModel product);
        Task<ProductDbModel? > DeleteById(int id);
        Task<List<ProductUiModel>> GetAllProduct();
        Task<ProductDbModel> GetById(int id);
        Task<List<ProductDbModel>> GetAllProductDb();
    }
}
