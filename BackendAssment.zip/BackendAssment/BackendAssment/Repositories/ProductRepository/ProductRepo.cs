﻿using AutoMapper;
using BackendAssment.DataAccessLayer;
using BackendAssment.Models.ProductTable;
using Microsoft.EntityFrameworkCore;

namespace BackendAssment.Repositories.ProductRepository
{
    public class ProductRepo:Iproduct
    {
        private readonly DataBaseDbContext db;
        private readonly IMapper mapper;


        public ProductRepo(DataBaseDbContext db , IMapper mapper)
        {
            this.db = db;
            this.mapper = mapper;
        }

        public async Task<bool> AddProduct(ProductUiModel product)
        {
            ProductDbModel DbProduct= mapper.Map<ProductDbModel>(product);
            var existingProduct = await db.Products.FirstOrDefaultAsync(x => x.ProductName == DbProduct.ProductName);
            if (existingProduct == null)
            {
                if (product.Image != null)
                {
                    string uniqueFileName = Guid.NewGuid() + Path.GetExtension(product.Image.FileName);
                    string path = Path.Combine(Directory.GetCurrentDirectory(), "uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    string filePath = Path.Combine(path, uniqueFileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await product.Image.CopyToAsync(stream);
                    }
                    DbProduct.ImgPath = "uploads/" + uniqueFileName;
                }
                db.Products.Add(DbProduct);
                await db.SaveChangesAsync();
                return true;
            }
            return false;

        }

        public async Task<ProductDbModel? > DeleteById(int id)
        {
            ProductDbModel data =await db.Products.Where(x => x.ProductId == id).FirstOrDefaultAsync();
            if (data != null)
            {
                db.Products.Remove(data);
                await db.SaveChangesAsync();
                return data;
            }
            else
            {
                return null;
            }
        }

        public async Task<List<ProductUiModel>> GetAllProduct()
        {
            List<ProductDbModel> dblst =await db.Products.ToListAsync();
            List<ProductUiModel> lst = mapper.Map<List<ProductUiModel>>(dblst);

            return lst;
        }

        public async Task<List<ProductDbModel>> GetAllProductDb()
        {
            List<ProductDbModel> dblst = await db.Products.ToListAsync();
            return dblst;
        }

        public async Task<ProductDbModel> GetById(int id)
        {
           ProductDbModel productDbModel =await db.Products.Where(x => x.ProductId == id).FirstOrDefaultAsync();
            if (productDbModel != null)
            {
                
                return productDbModel;
            }
            else
            {
                return new ProductDbModel();
            }
        }

        public async Task<ProductUiModel? > UpdateProduct(int id,ProductUiModel product)
        {
            //ProductDbModel productDbModel =await db.Products.Where(x => x.ProductId == id ).FirstOrDefaultAsync();

            //if (productDbModel != null)
            //{
            //    productDbModel.ProductName = product.ProductName;
            //    productDbModel.Description = product.Description;
            //    productDbModel.Price = product.Price;
            //    productDbModel.QunatityInStock = product.QunatityInStock;
            //    productDbModel.Feature = product.Feature;
            //    productDbModel.Category = product.Category;
            //    await db.SaveChangesAsync();
            //    return mapper.Map<ProductUiModel>(productDbModel);
            //}
            //else
            //{
            //    return new ProductUiModel();
            //}
            var existingProduct = await db.Products.FirstOrDefaultAsync(p => p.ProductId == id);
            if (existingProduct != null)
            {
                existingProduct.ProductName = product.ProductName;
                existingProduct.QunatityInStock = product.QunatityInStock;
                existingProduct.Price = product.Price;
                existingProduct.Category = product.Category;
                existingProduct.Description = product.Description;

                if (product.Image != null)
                {
                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + product.Image.FileName;
                    string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "uploads");

                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await product.Image.CopyToAsync(fileStream);
                    }

                    // Delete the old image file from the server
                    if (!string.IsNullOrEmpty(existingProduct.ImgPath))
                    {
                        string oldImagePath = Path.Combine(Directory.GetCurrentDirectory(), existingProduct.ImgPath);
                        if (File.Exists(oldImagePath))
                        {
                            File.Delete(oldImagePath);
                        }
                    }

                    existingProduct.ImgPath = "uploads/" + uniqueFileName;
                }


                await db.SaveChangesAsync();
                return product;
            }
            return null;
        }
    }
}
