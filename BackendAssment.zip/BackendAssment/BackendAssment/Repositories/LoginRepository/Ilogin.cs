﻿using BackendAssment.Models.LoginTable;
using BackendAssment.Models.UserTable;

namespace BackendAssment.Repositories.LoginRepository
{
    public interface Ilogin
    {
        Task<UserModel> Login(LoginModel model);
    }
}
