﻿using BackendAssment.DataAccessLayer;
using BackendAssment.Models.LoginTable;
using BackendAssment.Models.UserTable;
using Microsoft.EntityFrameworkCore;

namespace BackendAssment.Repositories.LoginRepository


{
    public class LoginRepo:Ilogin
    {
        private readonly DataBaseDbContext db;
        public LoginRepo(DataBaseDbContext dbContext)
        {
            db = dbContext;
        }
        public async Task<UserModel> Login(LoginModel model)
        {
            var data = await db.Users.Where(x => x.Email == model.Email).FirstOrDefaultAsync();
            if (data != null)
            {
               bool isVaild = BCrypt.Net.BCrypt.Verify(model.Password ,data.Password);
                if (isVaild) { 
                
                 return data;

                }
                else
                {
                    return new UserModel();
                }
            }
            else
            {
                return new UserModel();
            }
        }
    }
}
