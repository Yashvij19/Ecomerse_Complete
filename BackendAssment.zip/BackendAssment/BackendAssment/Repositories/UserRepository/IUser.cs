﻿using BackendAssment.Models.UserTable;

namespace BackendAssment.Repositories.UserRepository
{
    public interface IUser
    {

        Task<UserModel?> AddUser(UserModel user);

        Task<UserModel> UpdateUserByEmail(string email , UserModel model);

        Task<UserModel> UpdateUserById(int id , UserModel model);

        Task<UserModel> DeleteById(int id);

        Task<UserModel> GetById(int id);

        Task<UserModel> GetByEmail(string email);

        Task<List<UserModel>> GetAllUser();

        Task<bool> statusChange(int id);

        

    }
}
