﻿using AutoMapper;
using BackendAssment.DataAccessLayer;
using BackendAssment.Models.UserTable;
using Microsoft.EntityFrameworkCore;
using BCrypt.Net;
using Microsoft.AspNetCore.Mvc;

namespace BackendAssment.Repositories.UserRepository
{
    public class UserRepository : IUser
    {
        private readonly DataBaseDbContext db;

        public UserRepository (DataBaseDbContext db)
        {
            this.db = db;
        }

        public async Task<UserModel?> AddUser([FromForm] UserModel user)
        {
            // Check if the user already exists in the database
            var existingUser = await db.Users.FirstOrDefaultAsync(u => u.Email == user.Email);
            if (existingUser == null)
            {


                // Securely hash the password using bcrypt
                user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);

                await db.Users.AddAsync(user);

                await db.SaveChangesAsync();

                return user; // User successfully added
            }

            return null; // User already exists
        }

        public async Task<UserModel> DeleteById(int id)
        {
            var data = await db.Users.Where(x => x.UserId == id).FirstOrDefaultAsync();

            if (data != null) {

                db.Users.Remove(data);
                await db.SaveChangesAsync();
                return data;
            }
            else
            {
                return new UserModel();
            }

        }
        public async Task<List<UserModel>> GetAllUser()
        {
            List<UserModel> user=await db.Users.ToListAsync();

            return user;
        }

        public async Task<UserModel> GetByEmail(string email)
        {
            var data= await db.Users.Where(x=>x.Email == email).FirstOrDefaultAsync();

            if (data != null)
            {
                return data;

            }
            else
            {
                return new UserModel();
            }
        }

        public async Task<UserModel> GetById(int id)
        {
            var data = await db.Users.Where(x => x.UserId == id).FirstOrDefaultAsync();

            if (data != null)
            {
                return data;

            }
            else
            {
                return new UserModel();
            }
        }

        public async Task<UserModel> UpdateUserByEmail(string email  , UserModel model)
        {
            var data = await db.Users.Where(x => x.Email == email).FirstOrDefaultAsync();

            if (data != null)
            {
                data.UserName = model.UserName;
                data.Address = model.Address;
                data.Email = model.Email;
                data.Phone = model.Phone;
                data.CreditCard = model.CreditCard;
                await db.SaveChangesAsync();

                return data;
            }
            else
            {
                return new UserModel();
            }
        }
        public async Task<bool> statusChange(int id)
        {
            var data = await db.Users.Where(x => x.UserId == id).FirstOrDefaultAsync();

            if (data != null)
            {
                if (data.status == 1)
                {
                    data.status = 0;
                }
                else
                {
                    data.status = 1;
                }
                await db.SaveChangesAsync();
                return true;

            }
            else
            {
                return false;
            }
        }

        public async Task<UserModel> UpdateUserById(int id, UserModel model)
        {
            var data = await db.Users.Where(x => x.UserId == id).FirstOrDefaultAsync();

            if (data != null)
            {
                data.UserName = model.UserName;
                data.Address = model.Address;
                data.Email = model.Email;
                data.Phone = model.Phone;
                data.CreditCard = model.CreditCard;
                await db.SaveChangesAsync();

                return data;
            }
            else
            {
                return new UserModel();
            }
        }
    }
}
