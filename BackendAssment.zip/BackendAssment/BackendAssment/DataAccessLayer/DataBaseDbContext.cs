﻿using BackendAssment.Models.OrderInfoTable;
using BackendAssment.Models.OrderTable;
using BackendAssment.Models.ProductTable;
using BackendAssment.Models.UserTable;
using Microsoft.EntityFrameworkCore;

namespace BackendAssment.DataAccessLayer
{
    public class DataBaseDbContext(DbContextOptions<DataBaseDbContext> options):DbContext(options)
    {
     
        
        public DbSet<UserModel> Users { get; set; }

        public DbSet<ProductDbModel> Products { get; set; }

        public DbSet<OrderModel> Orders { get; set; }

        public DbSet<OrderItemModel> OrderItems { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<OrderModel>()
               .HasOne(o=>o.User)
               .WithMany(u=>u.OrderModels)
               .HasForeignKey(o=>o.UserId)
               .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<OrderItemModel>()
                .HasOne(oi => oi.Order)
                .WithMany(o => o.OrderItems)
                .HasForeignKey(oi => oi.OrderId)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<OrderItemModel>()
                .HasOne(oi=>oi.Product)
                .WithMany(p=>p.OrderItems)
                .HasForeignKey(oi=>oi.ProductId)
                .OnDelete(DeleteBehavior.Restrict);

        }

    }
}
