﻿using AutoMapper;
using BackendAssment.Models.ProductTable;

namespace BackendAssment.AutoMapper
{
    public class ApplicationMappingProfile:Profile
    {
        public ApplicationMappingProfile() {

            CreateMap<ProductDbModel, ProductUiModel>().ReverseMap();
            
        }
    }
}
