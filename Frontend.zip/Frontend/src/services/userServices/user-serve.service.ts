import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserServeService {

  constructor(private http:HttpClient) { }
  private API_URL ="https://localhost:7128"

  getAllUserDb(){
    let token: any = localStorage.getItem("authToken");
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
   return this.http.get(`${this.API_URL}/api/User/GetAllUser` , {headers})
  }

  addUser(data:any){
    return this.http.post(`${this.API_URL}/api/User/AddUser`,data)
  }
  
  getUserById(id:any){
    return this.http.get(`${this.API_URL}/api/User/Get/${id}`)
  }

  getStatusChange(id: any) {
    let token: any = localStorage.getItem("authToken");
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    return this.http.get(`${this.API_URL}/api/User/changeStatus/${id}`, { headers });
  }
}
