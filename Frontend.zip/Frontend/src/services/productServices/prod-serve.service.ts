import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProdServeService {

  constructor(private http:HttpClient) { }

  private API_URL ="https://localhost:7128"

  getAllProductsDb(){
    return this.http.get(`${this.API_URL}/api/Product/GetAllProductsDb`)
  }

  getProductUi(id:any){
    return this.http.get(`${this.API_URL}/api/Product/Get/${id}`)
  }
  

  addProductFromUi(data:any){
    return this.http.post(`${this.API_URL}/api/Product/AddProduct`, data)
  }

  updateProduct(id:any ,data:any){
    return this.http.put(`${this.API_URL}/api/Product/Update/${id}`, data)
  }

  deleteProduct(id:any){
    return this.http.delete(`${this.API_URL}/api/Product/Delete/${id}`)
  }
}
