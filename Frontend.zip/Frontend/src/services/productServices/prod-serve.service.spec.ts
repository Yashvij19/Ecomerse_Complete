import { TestBed } from '@angular/core/testing';

import { ProdServeService } from './prod-serve.service';

describe('ProdServeService', () => {
  let service: ProdServeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ProdServeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
