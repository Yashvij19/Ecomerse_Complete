import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { jwtDecode } from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class AuthServeService {

  constructor(private http:HttpClient) { }

  private API_URL ="https://localhost:7128"

  loginUser(data:any){
    return this.http.post(`${this.API_URL}/api/Login/login`, data, { responseType: 'text' })
  }
  getToken(){
    return localStorage.getItem("authToken");
  }
  // Function to check the role of the token
  getUserRoleFromToken(): string | null {
    // Retrieve the token from local storage
    const authToken = localStorage.getItem("authToken");
  
    // If the token does not exist, return null
    if (!authToken) {
      console.error("Token not found in local storage");
      return null;
    }
  
    try {
      // Decode the token using jwtDecode
      const decodedToken: any = jwtDecode(authToken);
  
      // Extract the user's role from the token (adjust key as necessary)
      const userRole = decodedToken['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
  
      // Return the user's role or null if not present
      return userRole || null;
  
    } catch (error) {
      // Handle errors during decoding (e.g., malformed token)
      console.error("Error decoding token:", error);
      return null;
    }
  }

}
