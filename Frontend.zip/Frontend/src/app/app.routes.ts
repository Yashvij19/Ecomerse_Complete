// import { Routes } from '@angular/router';
// import { MainComponent } from './components/main/main.component';
// import { HomeComponent } from './components/main/home/home.component';
// import { LoginComponent } from './components/main/login/login.component';
// import { RegisterComponent } from './components/main/register/register.component';
// import { DashboardComponent } from './components/dashboard/dashboard.component';
// import { AddProductComponent } from './components/dashboard/add-product/add-product.component';
// import { HomeDashboardComponent } from './components/dashboard/home-dashboard/home-dashboard.component';
// import { AboutComponent } from './components/main/about/about.component';
// import { ProductComponent } from './components/main/product/product.component';
// import { DashUserComponent } from './components/dashboard/dash-user/dash-user.component';
// import { MoreDetailCardComponent } from './components/main/more-detail-card/more-detail-card.component';
// import { EditComponent } from './components/dashboard/edit/edit.component';

// export const routes: Routes = [
//     {path:"" , component:MainComponent, children:[
//         {path:"" , component:HomeComponent},
//         {path:"login", component:LoginComponent},
//         {path:"register", component:RegisterComponent},
//         {path:"about", component:AboutComponent},
//         {path:"products", component:ProductComponent},
//         {path:"moredetail/:id", component:MoreDetailCardComponent}
//     ]},
//     {path:"dashboard" , component:DashboardComponent , children:[
//         {path:"addproduct", component:AddProductComponent},
//         {path:"" , component:HomeDashboardComponent},
//         {path:"users" , component:DashUserComponent},
//         {path:"editpro/:id", component:EditComponent}
//     ]}
// ];
import { Routes } from '@angular/router';
import { MainComponent } from './components/main/main.component';
import { HomeComponent } from './components/main/home/home.component';
import { LoginComponent } from './components/main/login/login.component';
import { RegisterComponent } from './components/main/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AddProductComponent } from './components/dashboard/add-product/add-product.component';
import { HomeDashboardComponent } from './components/dashboard/home-dashboard/home-dashboard.component';
import { AboutComponent } from './components/main/about/about.component';
import { ProductComponent } from './components/main/product/product.component';
import { DashUserComponent } from './components/dashboard/dash-user/dash-user.component';
import { MoreDetailCardComponent } from './components/main/more-detail-card/more-detail-card.component';
import { EditComponent } from './components/dashboard/edit/edit.component';
import { authGuardGuard } from './guards/auth-guard.guard';
import { adminGuard } from './guards/admin.guard';

export const routes: Routes = [
  { path: "", component: MainComponent, children: [
      { path: "", component: HomeComponent },
      { path: "login", component: LoginComponent },
      { path: "register", component: RegisterComponent },
      { path: "about", component: AboutComponent },
      { path: "products", component: ProductComponent },
      { path: "moredetail/:id", component: MoreDetailCardComponent }
  ]},

  { path: "dashboard", component: DashboardComponent, canActivate: [authGuardGuard, adminGuard], children: [
      { path: "addproduct", component: AddProductComponent },
      { path: "", component: HomeDashboardComponent },
      { path: "users", component: DashUserComponent },
      { path: "editpro/:id", component: EditComponent }
  ]}
];