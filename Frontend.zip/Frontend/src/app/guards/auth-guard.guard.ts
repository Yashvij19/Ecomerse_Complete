import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthServeService } from '../../services/authServices/auth-serve.service';

export const authGuardGuard: CanActivateFn = () => {
  const authService: any = inject(AuthServeService);
  const router: any = inject(Router);

  const authToken = localStorage.getItem('authToken');

  if (!authToken) {
    router.navigate(['/login']);
    return false;
  }

  return true;
};