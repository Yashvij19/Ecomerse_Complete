import { Component, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthServeService } from '../../../../services/authServices/auth-serve.service';
import { jwtDecode } from 'jwt-decode';

@Component({
  selector: 'app-login',
  imports: [RouterLink, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  loginForm:FormGroup=new FormGroup({
    email:new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required]),
  })

  router:any=inject(Router)
  auser:any=inject(AuthServeService)
  onSubmit(){
    let fData=this.loginForm.value;
    //whwn file upload send data through formData 
    let formData=new FormData();
    formData.append("Email",fData.email);
    formData.append("Password",fData.password);
    
    this.auser.loginUser(formData)
      .subscribe({
     next: (response:any) => {
    
      console.log(jwtDecode(response))
      let data: any = jwtDecode(response);
      if(data["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/stateorprovince"]==="1"){
      localStorage.setItem("authToken", response)
      console.log('Login successfully', response)
       if(data["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"] === "Admin"){
        this.router.navigate(["/dashboard"])
       }
        if(data["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"] === "User"){
         this.router.navigate(["/"])
       }
      }else{
        alert("Login faild because of your status is deativated")
        console.log('Login faild because of your status is deativated')
        this.router.navigate(["/"])
      }
    },
     error: (error:any) => {
      console.error('Error Occured', error)
      alert("email or password is incorrect")
    }

   });

  }
}
