import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoreDetailCardComponent } from './more-detail-card.component';

describe('MoreDetailCardComponent', () => {
  let component: MoreDetailCardComponent;
  let fixture: ComponentFixture<MoreDetailCardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MoreDetailCardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MoreDetailCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
