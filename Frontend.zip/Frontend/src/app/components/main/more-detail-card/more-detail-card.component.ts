import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ProdServeService } from '../../../../services/productServices/prod-serve.service';

@Component({
  selector: 'app-more-detail-card',
  imports: [FormsModule],
  templateUrl: './more-detail-card.component.html',
  styleUrl: './more-detail-card.component.css'
})
export class MoreDetailCardComponent {

  constructor(private route:ActivatedRoute){}
  productId:any;
  selectedQuantity: number = 1;
  proser:any=inject(ProdServeService)
  product:any

  ngOnInit() {
    // Extract the 'id' parameter from the route
    this.productId = this.route.snapshot.paramMap.get('id');

   this.proser.getProductUi(this.productId)
    .subscribe(
      {
        next:(data:any)=>{
          console.log("api response : ",data);
          this.product=data.data
          console.log(this.product)
        },
        error:(error:any)=>{
          console.log("api error: ", error)
        }
      }
    );
  }

  decreaseQuantity() {
    if (this.selectedQuantity > 1) {
      this.selectedQuantity--;
    }
  }

  increaseQuantity() {
    this.selectedQuantity++;
  }
  addToCart(){
    console.log("add in cart");
  }

buyNow(){
  console.log("product buy");
}
  
}
