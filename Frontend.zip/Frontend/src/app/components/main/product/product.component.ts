import { Component, inject } from '@angular/core';
import { ProdServeService } from '../../../../services/productServices/prod-serve.service';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-product',
  imports: [CommonModule],
  templateUrl: './product.component.html',
  styleUrl: './product.component.css'
})
export class ProductComponent {

  proser:any=inject(ProdServeService);

  products:any=[];

  router=inject(Router);

  ngOnInit(): void {
    this.proser.getAllProductsDb()
    .subscribe(
      {
        next:(data:any)=>{
          console.log("api response : ",data);
          this.products=data.data
          console.log(this.products)
        },
        error:(error:any)=>{
          console.log("api error: ", error)
        }
      }
    );
  }
  openMoreDetail(id:number){
   this.router.navigate(["/moredetail",id])
  }
}
