import { Component, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserServeService } from '../../../../services/userServices/user-serve.service';

@Component({
  selector: 'app-register',
  imports: [ReactiveFormsModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  
  registerForm: FormGroup = new FormGroup({
    UserName: new FormControl('', [Validators.required]),
    Email: new FormControl('', [Validators.required, Validators.email]),
    Password: new FormControl('', [Validators.required, Validators.minLength(6)]),
    Phone: new FormControl('', [Validators.required]),
    CreditCard: new FormControl('', [Validators.required]),
    Address: new FormControl('', [Validators.required])
  });

  userService: any = inject(UserServeService);
  router:any=inject(Router)

  onSubmit() {
    let fData = this.registerForm.value;
    let formData = {
      userId: "0",
      OrderModels: [],
      UserName: fData.UserName,
      Email: fData.Email,
      Password: fData.Password,
      Phone: fData.Phone,
      CreditCard: fData.CreditCard,
      Address: fData.Address
    };

    // Preparing data to send with default values for `userId` and `order`
   

    this.userService.addUser(formData).subscribe({
      next: (response: any) => {
        console.log('Registration successful', response);
        this.router.navigate(['/']);
      },
      error: (error: any) => console.log('Error occurred', error)
      
    });

  }

  onReset(){
    console.log("reset");
  }
}