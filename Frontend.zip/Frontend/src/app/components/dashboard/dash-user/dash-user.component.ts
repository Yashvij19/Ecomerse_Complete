// import { Component, inject , OnInit } from '@angular/core';
// import { UserServeService } from '../../../../services/userServices/user-serve.service';
// import { CommonModule } from '@angular/common';

// @Component({
//   selector: 'app-dash-user',
//   imports: [CommonModule],
//   templateUrl: './dash-user.component.html',
//   styleUrl: './dash-user.component.css'
// })
// export class DashUserComponent implements OnInit {

//   users:any=[]
//   userSer:any=inject(UserServeService)


// status: any;

// ngOnInit(): void {
//   this.userSer.getAllUserDb()
//     .subscribe({
//       next: (data: any) => {
//         console.log("API response ", data);
//         this.users = data.data;
//         console.log("All user array", this.users);
//       },
//       error: (error: any) => {
//         console.log("Error is ", error);
//       }
//     });

//   // Highlighted Change: Subscribed to the status observable for dynamic UI updates
//   this.userSer.status$.subscribe((data: any) => {
//     this.status = data;
//     console.log("Updated status:", this.status);
//   });
// }

// changeStatus(id: number) {
//   this.userSer.getStatusChange(id).subscribe({
//     next: (data: any) => {
//       console.log("Status change response", data);
//     },
//     error: (err: any) => {
//       console.log("Error occurred ", err);
//     }
//   });
// }

// }

import { Component, inject, OnInit } from '@angular/core';
import { UserServeService } from '../../../../services/userServices/user-serve.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dash-user',
  imports: [CommonModule],
  templateUrl: './dash-user.component.html',
  styleUrls: ['./dash-user.component.css']
})
export class DashUserComponent implements OnInit {

  users: any = [];
  userSer: any = inject(UserServeService);
  status: any;

  ngOnInit(): void {
    this.userSer.getAllUserDb()
      .subscribe({
        next: (data: any) => {
          console.log("API response ", data);
          this.users = data.data;
          console.log("All user array", this.users);
        },
        error: (error: any) => {
          console.log("Error is ", error);
        }
      });

    // Subscribed to the status observable for dynamic updates
    
  }

  changeStatus(id: number) {
    
    this.userSer.getStatusChange(id).subscribe({
      next: (data: any) => {
        console.log("Status change response", data);
        alert("status change successfully");
      },
      error: (err: any) => {
        console.log("Error occurred ", err);
      }
    });
  }
}