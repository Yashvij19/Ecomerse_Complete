import { Component, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-dash-navbar',
  imports: [RouterLink ],
  templateUrl: './dash-navbar.component.html',
  styleUrl: './dash-navbar.component.css'
})
export class DashNavbarComponent {

  router:any=inject(Router)

  logout(){
    localStorage.removeItem("authToken");
    this.router.navigate(['/login']);
  }

}
