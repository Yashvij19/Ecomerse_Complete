import { Component } from '@angular/core';
import { DashNavbarComponent } from './dash-navbar/dash-navbar.component';
import { FooterComponent } from '../main/footer/footer.component';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  imports: [DashNavbarComponent , FooterComponent ,RouterOutlet],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {

}
