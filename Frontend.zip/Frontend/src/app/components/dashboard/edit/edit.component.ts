import { Component, inject , OnInit } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ProdServeService } from '../../../../services/productServices/prod-serve.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-edit',
  imports: [ReactiveFormsModule],
  templateUrl: './edit.component.html',
  styleUrl: './edit.component.css'
})
export class EditComponent implements OnInit {

  proser:any=inject(ProdServeService)
  filePathRef:any=""
 router:any=inject(Router)
 id:any

 constructor(private aroute:ActivatedRoute){}
  myForm:FormGroup=new FormGroup({
    productName:new FormControl('',[Validators.required]),
    description:new FormControl('',[Validators.required]),
    price:new FormControl('',[Validators.required]),
    qunatityInStock:new FormControl('', [Validators.required]),
    category:new FormControl('',[Validators.required]),
    feature:new FormControl('', [Validators.required]),

  })

  uploadFile(event: any) {
    if(event.target.files.length>0){
      let fileRef=event.target.files[0];
      console.log(fileRef)
      this.filePathRef=fileRef;
    }
  }
  ngOnInit(): void {
    this.id=this.aroute.snapshot.paramMap.get('id');//get params
    console.log(this.id)
    this.proser.getProductUi(this.id)
    .subscribe({
        next:(data:any)=>{
          this.myForm.patchValue(data.data);
          console.log(data.data)
        },
        error:(err:any)=>{
           console.log(err)
        }
    })
  }


  onSubmit(){
    let fData=this.myForm.value;
    //whwn file upload send data through formData
    let formData=new FormData();
    formData.append("Category",fData.category);
    formData.append("ProductName",fData.productName);
    formData.append("Description",fData.description);
    formData.append("Price",fData.price);
    formData.append("QunatityInStock",fData.qunatityInStock);
    formData.append("Feature",fData.feature);
    formData.append("Image", this.filePathRef, this.filePathRef.name);
    this.proser.updateProduct(this.id,formData).subscribe({
     next: (response:any) => {console.log('Product added successfully', response);
      this.router.navigate(["/dashboard"])
     },
     error: (error:any) => console.error('Error adding product', error),
   });
  }

  
  
}
