import { Component, inject , OnInit } from '@angular/core';
import { ProdServeService } from '../../../../services/productServices/prod-serve.service';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home-dashboard',
  imports: [CommonModule, RouterLink],
  templateUrl: './home-dashboard.component.html',
  styleUrl: './home-dashboard.component.css'
})
export class HomeDashboardComponent implements OnInit {

  proser:any=inject(ProdServeService);

  products:any=[];

  router=inject(Router);

  ngOnInit(): void {
    this.proser.getAllProductsDb()
    .subscribe(
      {
        next:(data:any)=>{
          console.log("api response : ",data);
          this.products=data.data
          console.log(this.products)
        },
        error:(error:any)=>{
          console.log("api error: ", error)
        }
      }
    );
  }
  deleteProduct(id: number): void {
    if (confirm("Are you sure you want to delete this product?")) {
      this.proser.deleteProduct(id).subscribe({
        next: () => {
          // Remove the deleted product from the frontend
          this.products = this.products.filter((product:any) => product.productId !== id);
          console.log(`Product with ID ${id} deleted`);
        },
        error: (error:any) => {
          console.error("Error deleting product:", error);
        }
      });
    }
  }

}
