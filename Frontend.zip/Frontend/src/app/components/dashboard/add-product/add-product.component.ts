import { Component, Inject, inject } from '@angular/core';
import { ProdServeService } from '../../../../services/productServices/prod-serve.service';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  imports: [ReactiveFormsModule],
  templateUrl: './add-product.component.html',
  styleUrl: './add-product.component.css'
})
export class AddProductComponent {

  proser:any=inject(ProdServeService)
  filePathRef:any=""
 router:any=inject(Router)

  myForm:FormGroup=new FormGroup({
    productName:new FormControl('',[Validators.required]),
    description:new FormControl('',[Validators.required]),
    price:new FormControl('',[Validators.required]),
    quantity:new FormControl('', [Validators.required]),
    category:new FormControl('',[Validators.required]),
    feature:new FormControl('', [Validators.required]),

  })

  uploadFile(event: any) {
    if(event.target.files.length>0){
      let fileRef=event.target.files[0];
      console.log(fileRef)
      this.filePathRef=fileRef;
    }
  }


  onSubmit(){
    let fData=this.myForm.value;
    //whwn file upload send data through formData
    let formData=new FormData();
    formData.append("Category",fData.category);
    formData.append("ProductName",fData.productName);
    formData.append("Description",fData.description);
    formData.append("Price",fData.price);
    formData.append("QunatityInStock",fData.quantity);
    formData.append("Feature",fData.feature);
    formData.append("Image",this.filePathRef,this.filePathRef.name)

    this.proser.addProductFromUi(formData).subscribe({
     next: (response:any) => console.log('Product added successfully', response),
     error: (error:any) => console.error('Error adding product', error),
   });
  }

  afterSubmit(){
    this.router.navigate(["dashboard/home"])
  }
  
}
